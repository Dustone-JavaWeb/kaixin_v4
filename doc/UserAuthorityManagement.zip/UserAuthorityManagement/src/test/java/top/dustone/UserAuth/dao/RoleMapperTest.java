package top.dustone.UserAuth.dao;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.exceptions.verification.NeverWantedButInvoked;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import top.dustone.uams.dao.RoleMapper;
@RunWith(SpringRunner.class)
@SpringBootTest
public class RoleMapperTest {
	@Autowired
	RoleMapper roleMapper;
	@Test
	public void testFindMenuRoles() {
//		System.err.println(roleMapper.findRoleMenus(1));
//		System.err.println(roleMapper.findRoleMenus(1).getClass().getName());
//		List<Integer> test=new ArrayList<Integer>();
//		test.add(2);
//		test.add(3);
//		Map<String,Object> param=new HashMap<String,Object>();
//		param.put("list", test);
//		param.put("rId", 2);
//		roleMapper.deleteRoleMenus(param);
		System.err.println(roleMapper.findRolesByUserId(1));
	}

}
