package top.dustone.UserAuth.service;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.github.pagehelper.PageHelper;

import top.dustone.uams.pojo.User;
import top.dustone.uams.service.UserService;
import top.dustone.uams.util.AjaxModel;
@RunWith(SpringRunner.class)
@SpringBootTest
public class UserServiceTest {
	@Autowired
	UserService userService;

	@Test
	public void testListByExample() {
//		AjaxModel<User> ajaxModel=new AjaxModel<User>();
//		User user1=new User();
//		ajaxModel.setExample(user1);
//		ajaxModel=userService.listByExample(ajaxModel);
//		//System.err.println(ajaxModel.getPageInfo().getList().size());
//		for(User user:ajaxModel.getPageInfo().getList()) {
//			//System.err.println(user);
//		}
	}

	@Test
	public void testUpdate() {
//		User user=new User();
//		user.setId(1);
//		user.setAccountNumber("admin");
//		user.setPassword("21232");
//		user.setName("陈岩测试");
//		user.setSex("男");
//		user.setPhone("13048062053");
//		user.setMail("12315@163.com");
//		user.setDisabled(false);
//		userService.update(user);
	}

	@Test
	public void testInsert() {
		User user=new User();
		user.setAccountNumber("123412421423");
		user.setPassword("213123");
		user.setName("测试用例");
		userService.insert(user);
		System.err.println(user);
	}

	@Test
	public void testLogicDelete() {
//		User user=new User();
//		user.setId(1);
//		userService.logicDelete(user);
	}

}
