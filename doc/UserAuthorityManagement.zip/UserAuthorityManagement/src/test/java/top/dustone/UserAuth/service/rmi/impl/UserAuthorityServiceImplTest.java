package top.dustone.UserAuth.service.rmi.impl;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import top.dustone.uams.pojo.User;
import top.dustone.uams.service.rmi.UserAuthorityService;
@RunWith(SpringRunner.class)
@SpringBootTest
public class UserAuthorityServiceImplTest {
	@Autowired
	UserAuthorityService userAuthorityService;
	@Test
	public void testUserAuth() {
		User user=new User();
		user.setAccountNumber("kaixin");
		user.setPassword("123456");
		User result=userAuthorityService.userAuth(user, "铠信后台管理");
		System.err.println(result);
	}
	@Test
	public void testTree() {
		System.err.println(userAuthorityService.getMenuTreeByRoleId(4));
	}

}
