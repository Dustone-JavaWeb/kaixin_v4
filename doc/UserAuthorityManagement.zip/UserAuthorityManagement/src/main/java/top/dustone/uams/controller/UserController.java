package top.dustone.uams.controller;

import javax.jws.soap.SOAPBinding.Use;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import top.dustone.uams.pojo.Role;
import top.dustone.uams.pojo.User;
import top.dustone.uams.pojo.UserRoles;
import top.dustone.uams.service.UserService;
import top.dustone.uams.util.AjaxModel;
@CrossOrigin
@RequestMapping("/user")
@RestController
public class UserController {
	@Autowired
	UserService userService;
	@PostMapping("/list")
	public AjaxModel<User> listByExample(@RequestBody AjaxModel<User> ajaxModel){
		return userService.listByExample(ajaxModel);
	}
	@PostMapping("/listWithRoles")
	public AjaxModel<UserRoles> listUsersWithRoles(@RequestBody AjaxModel<UserRoles> ajaxModel){
		return userService.listUsersWithRoles(ajaxModel);
	}
	@PostMapping("/findById")
	public AjaxModel<User> findById(@RequestBody AjaxModel<User> ajaxModel){
		return userService.findById(ajaxModel);
	}
	@PostMapping("/insert")
	public AjaxModel<User> insert(@RequestBody AjaxModel<User> ajaxModel){
		ajaxModel.setExample(userService.insert(ajaxModel.getExample()));
		return ajaxModel;
	}
	@PostMapping("/update")
	public AjaxModel<User> update(@RequestBody AjaxModel<User> ajaxModel){
		ajaxModel.setExample(userService.update(ajaxModel.getExample()));
		return ajaxModel;
	}
	@PostMapping("/delete")
	public AjaxModel<User> delete(@RequestBody AjaxModel<User> ajaxModel){
		userService.logicDelete(ajaxModel.getExample());
		return ajaxModel;
	}
	@GetMapping("/checkAccountUnique")
	public boolean checkAccountUnique(@RequestParam("accountNumber") String accountNumber){
		return userService.checkAccountNumberUnique(accountNumber);
	}
	@PostMapping("/updateRoles")
	public AjaxModel<UserRoles> updateRoles(@RequestBody AjaxModel<UserRoles> ajaxModel){
//		System.err.println(ajaxModel);
		userService.updateUserRoles(ajaxModel.getExample().getUserId(), ajaxModel.getTrids());
		return ajaxModel;
	}
}
