/**
 * copyright
 */
package top.dustone.uams.service.rmi.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import top.dustone.uams.dao.MenuMapper;
import top.dustone.uams.dao.RoleMapper;
import top.dustone.uams.dao.UserMapper;
import top.dustone.uams.pojo.Role;
import top.dustone.uams.pojo.User;
import top.dustone.uams.service.rmi.UserAuthorityService;
import top.dustone.uams.util.SimpleMenuInfo;

/**
 * 
 * @author Dustone
 * @since 2019-04-1
 *
 */
@Service("userAuthorityService")
public class UserAuthorityServiceImpl implements UserAuthorityService{
	@Autowired
	private UserMapper userMapper;
	
	@Autowired
	private RoleMapper roleMaper;
	
	@Autowired
	private MenuMapper menuMapper;
	
	@Override
	public User userAuth(User user,String targetRoleName) {
		User errorUser=new User();
		errorUser.setSex("ERROR");
		
		//校验登陆
		if (user.getAccountNumber()==null || user.getPassword()==null || targetRoleName==null) {
			errorUser.setName("用户名或密码错误");
			return errorUser;
		}
		
		User targetUser=userMapper.findUserByAccountNumber(user.getAccountNumber());
		if (targetUser==null || !user.getPassword().equals(targetUser.getPassword())) {
			errorUser.setName("用户名或密码错误");
			return errorUser;
		}
		
		targetUser.setPassword("");
		
		//校验权限
		List<Role> roles = roleMaper.findRolesByUserId(targetUser.getId());
		
		Role targetRole=null;	
		
		for(Role r:roles) {
			if(r.getName()==null) {
				continue;
			}
			if(r.getName().startsWith(targetRoleName)) {
				targetRole=r;
				break;
			}
		}
		
		if(targetRole==null) {
			errorUser.setName("用户没有登陆该系统的权限！");
			return errorUser;
		}
		
		//装载URL
		targetUser.setRoleName(targetRole.getName());
		targetUser.setRoleId(targetRole.getId());
		targetUser.setAuthUrls(menuMapper.findMenuURLByRoleId(targetRole.getId()));
		return targetUser;
	}
	@Override
	public List<SimpleMenuInfo> getMenuTreeByRoleId(int roleId) {
		List<SimpleMenuInfo> genic = menuMapper.findSimpleMenuByRoleId(roleId);
		List<SimpleMenuInfo> firstLevel = new ArrayList<SimpleMenuInfo>();
		List<SimpleMenuInfo> secondLevel = new ArrayList<SimpleMenuInfo>();
		// List<SimpleMenuInfo>
		for (SimpleMenuInfo gInfo : genic) {
			if (gInfo.getParentId() == 0) {
				firstLevel.add(gInfo);
			} else {
				secondLevel.add(gInfo);
			}
		}
		for (SimpleMenuInfo fInfo : firstLevel) {
			for (SimpleMenuInfo sInfo : secondLevel) {
				if (sInfo.getParentId() == fInfo.getId()) {
					// 装载二级菜单
					if (fInfo.getChilds() == null) {
						fInfo.setChilds(new ArrayList<SimpleMenuInfo>());
					}
					fInfo.getChilds().add(sInfo);
					sInfo.setChilds(new ArrayList<SimpleMenuInfo>());
					// 装载三级菜单
					for (SimpleMenuInfo tInfo : secondLevel) {
						if (tInfo.getParentId() == sInfo.getId()) {
							sInfo.getChilds().add(tInfo);
						}
					}
				}
			}
		}
		return firstLevel;
	}
}
