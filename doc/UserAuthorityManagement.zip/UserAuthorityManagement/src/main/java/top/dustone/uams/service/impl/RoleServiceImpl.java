package top.dustone.uams.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import oracle.net.aso.n;
import top.dustone.uams.dao.RoleMapper;
import top.dustone.uams.pojo.Role;
import top.dustone.uams.service.RoleService;
import top.dustone.uams.util.AjaxModel;

@Service
public class RoleServiceImpl implements RoleService{
	@Autowired
	RoleMapper roleMapper;
	@Override
	public AjaxModel<Role> listByExample(AjaxModel<Role> request) {
		PageHelper.startPage(request.getStartPage(),request.getPageSize());
		List<Role> result=roleMapper.listByExample(request.getExample());
        PageInfo<Role> pageInfo=new PageInfo<>(result,request.getPageSize());
		request.setPageInfo(pageInfo);
		return request;
	}

	@Override
	public Role update(Role t) {
		roleMapper.update(t);
		return t;
	}

	@Override
	public Role insert(Role t) {
		int id=roleMapper.insert(t);
		t.setId(id);
		return t;
	}

	@Override
	public Role logicDelete(Role t) {
		int id=roleMapper.logicDelete(t);
		t.setId(id);
		return t;
	}

	@Override
	public AjaxModel<Role> findById(AjaxModel<Role> request) {
		request.setExample(roleMapper.findById(request.getExample().getId()));
		return request;
	}
	

	@Override
	public String updateRoleMenus(int roleId, int[] menuIds) {
		List<Integer> menuNeedToDel=new LinkedList<>(roleMapper.findRoleMenus(roleId));
		List<Integer> menuNeedToAdd=new ArrayList<Integer>();
		//处理新增和删除
		for(int menuId:menuIds) {
			int point=menuNeedToDel.indexOf(menuId);
			if(point==-1) {
				menuNeedToAdd.add(menuId);
			}else {
				menuNeedToDel.remove(point);
			}
		}
		if(menuNeedToAdd.size()!=0) {
			Map<String, Object> params=new HashMap<String,Object>();
			params.put("list", menuNeedToAdd);
			params.put("rId", roleId);
			roleMapper.insertRoleMenus(params);
		}
		if(menuNeedToDel.size()!=0) {
			Map<String, Object> params=new HashMap<String,Object>();
			params.put("list", menuNeedToDel);
			params.put("rId", roleId);
			roleMapper.deleteRoleMenus(params);
		}
		return "ok";
	}

	@Override
	public Integer[] findMenusByRoleId(int roleId) {
		List<Integer> results=roleMapper.findRoleMenus(roleId);
		Integer[] result=new Integer[results.size()];
		results.toArray(result);
		return result;
	}

	@Override
	public List<Role> findSimpleRole() {
		// TODO 自动生成的方法存根
		return roleMapper.findSimpleRole();
	}
}
