package top.dustone.uams.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import top.dustone.uams.pojo.Role;
@Mapper
public interface RoleMapper extends BaseMapper<Role>{
	public List<Integer> findRoleMenus(int roleId);
	public void insertRoleMenus(Map<String, Object> params);
	public void deleteRoleMenus(Map<String, Object> params);
	public List<Role> findRolesByUserId(int userId);
	public List<Role> findSimpleRole();
}
