package top.dustone.uams.util;

import java.util.Arrays;
import java.util.List;

import com.github.pagehelper.PageInfo;

public class AjaxModel<T> {
	//标准数据
	private T example;
	private int[] trids;
	private String msg;
	private String code;
	private int startPage=1;
	private int pageSize=5;
	//分页信息
	private PageInfo<T> pageInfo;
	public T getExample() {
		return example;
	}
	public void setExample(T example) {
		this.example = example;
	}
	public int[] getTrids() {
		return trids;
	}
	public void setTrids(int[] trids) {
		this.trids = trids;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public PageInfo<T> getPageInfo() {
		return pageInfo;
	}
	public void setPageInfo(PageInfo<T> pageInfo) {
		this.pageInfo = pageInfo;
	}
	public int getStartPage() {
		return startPage;
	}
	public void setStartPage(int startPage) {
		this.startPage = startPage;
	}
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	@Override
	public String toString() {
		return "AjaxModel [example=" + example + ", trids=" + Arrays.toString(trids) + ", msg=" + msg + ", code=" + code
				+ ", startPage=" + startPage + ", pageSize=" + pageSize + ", pageInfo=" + pageInfo + "]";
	}
	
}
