package top.dustone.uams.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import top.dustone.uams.pojo.User;
import top.dustone.uams.pojo.UserRoles;

@Mapper
public interface UserMapper extends BaseMapper<User>{
	public List<UserRoles> listUsersWithRoles(UserRoles userRoles);
	public List<Integer> findUserRoles(int userId);
	public User findUserByAccountNumber(String accountNumber);
	public void insertUserRoles(Map<String, Object> params);
	public void deleteUserRoles(Map<String, Object> params);
}
