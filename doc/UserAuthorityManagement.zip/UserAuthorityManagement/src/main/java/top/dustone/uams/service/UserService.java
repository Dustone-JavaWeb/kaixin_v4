package top.dustone.uams.service;

import top.dustone.uams.pojo.User;
import top.dustone.uams.pojo.UserRoles;
import top.dustone.uams.util.AjaxModel;

public interface UserService extends BaseService<User>{
	public boolean checkAccountNumberUnique(String accountNumber);
	public AjaxModel<UserRoles> listUsersWithRoles(AjaxModel<UserRoles> request);
	public String updateUserRoles(int userId,int[] roleIds);
}
