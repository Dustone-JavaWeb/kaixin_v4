package top.dustone.uams.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.HtmlUtils;

import top.dustone.uams.pojo.User;
import top.dustone.uams.service.rmi.UserAuthorityService;
import top.dustone.uams.util.AjaxModel;
@RestController
public class LoginController {
	public static String[] URL_ALL={

    };
    @Autowired
    private UserAuthorityService userAuthorityService;
    @PostMapping(value = "/login")
    public AjaxModel<User> login(@RequestBody User user, HttpSession session){
        AjaxModel<User> result=new AjaxModel<User>();
        String accountNumber =  user.getAccountNumber();
        accountNumber = HtmlUtils.htmlEscape(accountNumber);
        user =userAuthorityService.userAuth(user,"超级管理员");
        //System.out.println(user);
        if("ERROR".equals(user.getSex())){
            result.setMsg(user.getName());
            result.setCode("404");
            return result;
        }
        else{
            for(String str:URL_ALL){
                user.getAuthUrls().add(str);
            }
            result.setMsg("登陆成功");
            result.setCode("200");
            session.setAttribute("MyUser",user);
            //System.err.println(session.getId());
            return result;
        }
    }
    @GetMapping(value="/sys_info")
    public AjaxModel<User> getUserInfo(HttpSession session){
        AjaxModel<User> result=new AjaxModel<User>();
        User user=(User) session.getAttribute("MyUser");
        //System.err.println(session.getId());
        if(null==user){
            result.setMsg("Session信息异常！ 请重新登陆");
            result.setCode("404");
            return result;
        }
        else{
            result.setExample(user);
            result.setCode("200");
            return result;
        }
    }
    @GetMapping(value="/sys_logout")
    public AjaxModel<User> logOut(HttpSession session){
        AjaxModel<User> result=new AjaxModel<User>();
        session.removeAttribute("MyUser");
        result.setCode("200");
        result.setMsg("注销成功！ 即将返回登陆界面！");
        //System.out.println(result);
        return result;
    }
}
