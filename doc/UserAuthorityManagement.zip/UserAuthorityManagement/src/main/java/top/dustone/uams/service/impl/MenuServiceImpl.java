package top.dustone.uams.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import top.dustone.uams.dao.MenuMapper;
import top.dustone.uams.pojo.Menu;
import top.dustone.uams.service.MenuService;
import top.dustone.uams.util.AjaxModel;
import top.dustone.uams.util.SimpleMenuInfo;

@Service
public class MenuServiceImpl implements MenuService {
	@Autowired
	MenuMapper menuMapper;

	@Override
	public AjaxModel<Menu> listByExample(AjaxModel<Menu> request) {
		PageHelper.startPage(request.getStartPage(), request.getPageSize());
		List<Menu> result = menuMapper.listByExample(request.getExample());
		PageInfo<Menu> pageInfo = new PageInfo<>(result, request.getPageSize());
		request.setPageInfo(pageInfo);
		return request;
	}

	@Override
	public Menu update(Menu t) {
		menuMapper.update(t);
		return t;
	}

	@Override
	public Menu insert(Menu t) {
		int id = menuMapper.insert(t);
		t.setId(id);
		return t;
	}

	@Override
	public Menu logicDelete(Menu t) {
		int id = menuMapper.logicDelete(t);
		t.setId(id);
		return t;
	}

	@Override
	public AjaxModel<Menu> findById(AjaxModel<Menu> request) {
		request.setExample(menuMapper.findById(request.getExample().getId()));
		return request;
	}

	@Override
	public List<SimpleMenuInfo> findMenuInfoByType(int type) {
		return menuMapper.findMenuInfoByType(type);
	}

	@Override
	public List<SimpleMenuInfo> generateMenuTree() {
		List<SimpleMenuInfo> genic = menuMapper.findMenuInfoByType(0);
		List<SimpleMenuInfo> firstLevel = new ArrayList<SimpleMenuInfo>();
		List<SimpleMenuInfo> secondLevel = new ArrayList<SimpleMenuInfo>();
		// List<SimpleMenuInfo>
		for (SimpleMenuInfo gInfo : genic) {
			if (gInfo.getParentId() == 0) {
				firstLevel.add(gInfo);
			} else {
				secondLevel.add(gInfo);
			}
		}
		for (SimpleMenuInfo fInfo : firstLevel) {
			for (SimpleMenuInfo sInfo : secondLevel) {
				if (sInfo.getParentId() == fInfo.getId()) {
					// 装载二级菜单
					if (fInfo.getChilds() == null) {
						fInfo.setChilds(new ArrayList<SimpleMenuInfo>());
					}
					fInfo.getChilds().add(sInfo);
					sInfo.setChilds(new ArrayList<SimpleMenuInfo>());
					// 装载三级菜单
					for (SimpleMenuInfo tInfo : secondLevel) {
						if (tInfo.getParentId() == sInfo.getId()) {
							sInfo.getChilds().add(tInfo);
						}
					}
				}
			}
		}
		return firstLevel;
	}
}
