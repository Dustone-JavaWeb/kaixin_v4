package top.dustone.uams.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import top.dustone.uams.pojo.Menu;
import top.dustone.uams.util.SimpleMenuInfo;
@Mapper
public interface MenuMapper extends BaseMapper<Menu>{
	public List<SimpleMenuInfo> findMenuInfoByType(int type);
	public List<String> findMenuURLByRoleId(int roleId);
	public List<SimpleMenuInfo> findSimpleMenuByRoleId(int roleId);
}
