package top.dustone.uams.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import top.dustone.uams.pojo.Menu;
import top.dustone.uams.service.MenuService;
import top.dustone.uams.util.AjaxModel;
import top.dustone.uams.util.SimpleMenuInfo;

@CrossOrigin
@RequestMapping("/menu")
@RestController
public class MenuController {
	@Autowired
	MenuService menuService;
	@PostMapping("/list")
	public AjaxModel<Menu> listByExample(@RequestBody AjaxModel<Menu> ajaxModel){
		return menuService.listByExample(ajaxModel);
	}
	@PostMapping("/findById")
	public AjaxModel<Menu> findById(@RequestBody AjaxModel<Menu> ajaxModel){
		return menuService.findById(ajaxModel);
	}
	@PostMapping("/insert")
	public AjaxModel<Menu> insert(@RequestBody AjaxModel<Menu> ajaxModel){
		ajaxModel.setExample(menuService.insert(ajaxModel.getExample()));
		return ajaxModel;
	}
	@PostMapping("/update")
	public AjaxModel<Menu> update(@RequestBody AjaxModel<Menu> ajaxModel){
		ajaxModel.setExample(menuService.update(ajaxModel.getExample()));
		return ajaxModel;
	}
	@PostMapping("/delete")
	public AjaxModel<Menu> delete(@RequestBody AjaxModel<Menu> ajaxModel){
		menuService.logicDelete(ajaxModel.getExample());
		return ajaxModel;
	}
	@GetMapping("/menuInfo")
	public List<SimpleMenuInfo> getMenuInfo(@RequestParam("type") int type){
		return menuService.findMenuInfoByType(type);
	}
	@GetMapping("/menuTree")
	public List<SimpleMenuInfo> menuTree(){
		return menuService.generateMenuTree();
	}
}

