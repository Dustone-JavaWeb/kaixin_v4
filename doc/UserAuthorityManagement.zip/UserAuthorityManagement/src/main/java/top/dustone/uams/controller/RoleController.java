package top.dustone.uams.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import top.dustone.uams.pojo.Role;
import top.dustone.uams.service.RoleService;
import top.dustone.uams.util.AjaxModel;

@CrossOrigin
@RequestMapping("/role")
@RestController
public class RoleController {
	@Autowired
	RoleService roleService;
	@PostMapping("/list")
	public AjaxModel<Role> listByExample(@RequestBody AjaxModel<Role> ajaxModel){
		return roleService.listByExample(ajaxModel);
	}
	@GetMapping("/findSimple")
	public List<Role> findSimple(){
		return roleService.findSimpleRole();
	}
	@PostMapping("/findById")
	public AjaxModel<Role> findById(@RequestBody AjaxModel<Role> ajaxModel){
		return roleService.findById(ajaxModel);
	}
	@PostMapping("/insert")
	public AjaxModel<Role> insert(@RequestBody AjaxModel<Role> ajaxModel){
		ajaxModel.setExample(roleService.insert(ajaxModel.getExample()));
		return ajaxModel;
	}
	@PostMapping("/update")
	public AjaxModel<Role> update(@RequestBody AjaxModel<Role> ajaxModel){
		ajaxModel.setExample(roleService.update(ajaxModel.getExample()));
		return ajaxModel;
	}
	@PostMapping("/delete")
	public AjaxModel<Role> delete(@RequestBody AjaxModel<Role> ajaxModel){
		roleService.logicDelete(ajaxModel.getExample());
		return ajaxModel;
	}
	@GetMapping("/findMenus")
	public Integer[] findMenus(@RequestParam("rId") int rId) {
		return roleService.findMenusByRoleId(rId);
	}
	@PostMapping("/updateMenus")
	public AjaxModel<Role> updateMenus(@RequestBody AjaxModel<Role> ajaxModel){
		roleService.updateRoleMenus(ajaxModel.getExample().getId(), ajaxModel.getTrids());
		return ajaxModel;
	}
}
