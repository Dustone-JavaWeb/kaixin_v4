package top.dustone.uams.service.rmi;

import java.util.List;

import top.dustone.uams.pojo.Menu;
import top.dustone.uams.pojo.User;
import top.dustone.uams.util.SimpleMenuInfo;

public interface UserAuthorityService {
	public User userAuth(User user,String targetRoleName);

	public List<SimpleMenuInfo> getMenuTreeByRoleId(int roleId);
}
