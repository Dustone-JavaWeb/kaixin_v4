package top.dustone.uams;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.CrossOrigin;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		// TODO 自动生成的方法存根
		SpringApplication.run(Application.class, args);
	}

}
