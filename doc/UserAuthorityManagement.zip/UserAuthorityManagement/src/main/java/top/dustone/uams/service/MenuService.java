package top.dustone.uams.service;

import java.util.List;

import top.dustone.uams.pojo.Menu;
import top.dustone.uams.util.SimpleMenuInfo;

public interface MenuService extends BaseService<Menu>{
	public List<SimpleMenuInfo> findMenuInfoByType(int type);
	public List<SimpleMenuInfo> generateMenuTree();
}
