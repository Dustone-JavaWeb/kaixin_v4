package top.dustone.uams.pojo;

import java.util.List;

public class UserRoles {
	private int userId;
	private String accountNumber;
	private String userName;
	private List<Role> roles;
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public List<Role> getRoles() {
		return roles;
	}
	public void setRoles(List<Role> roles) {
		this.roles = roles;
	}
	@Override
	public String toString() {
		return "UserRoles [userId=" + userId + ", accountNumber=" + accountNumber + ", userName=" + userName
				+ ", roles=" + roles + "]";
	}
}
