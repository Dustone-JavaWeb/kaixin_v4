package top.dustone.uams.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import top.dustone.uams.dao.UserMapper;
import top.dustone.uams.pojo.User;
import top.dustone.uams.pojo.UserRoles;
import top.dustone.uams.service.UserService;
import top.dustone.uams.util.AjaxModel;
@Service
public class UserServiceImpl implements UserService{
	@Autowired
	UserMapper userMapper;
	@Override
	public AjaxModel<User> listByExample(AjaxModel<User> request) {
		PageHelper.startPage(request.getStartPage(),request.getPageSize());
		List<User> result=userMapper.listByExample(request.getExample());
        PageInfo<User> pageInfo=new PageInfo<>(result,request.getPageSize());
		request.setPageInfo(pageInfo);
		return request;
	}

	@Override
	public User update(User t) {
		userMapper.update(t);
		return t;
	}

	@Override
	public User insert(User t) {
		int id=userMapper.insert(t);
		t.setId(id);
		return t;
	}

	@Override
	public User logicDelete(User t) {
		int id=userMapper.logicDelete(t);
		t.setId(id);
		return t;
	}

	@Override
	public AjaxModel<User> findById(AjaxModel<User> request) {
		request.setExample(userMapper.findById(request.getExample().getId()));
		return request;
	}

	@Override
	public boolean checkAccountNumberUnique(String accountNumber) {
		User user=new User();
		user.setAccountNumber(accountNumber);
		List<User> result=userMapper.listByExample(user);
		if(result.size()>0) {
			return false;
		}
		return true;
	}

	@Override
	public AjaxModel<UserRoles> listUsersWithRoles(AjaxModel<UserRoles> request) {
		PageHelper.startPage(request.getStartPage(),request.getPageSize());
		List<UserRoles> result=userMapper.listUsersWithRoles(request.getExample());
        PageInfo<UserRoles> pageInfo=new PageInfo<>(result,request.getPageSize());
		request.setPageInfo(pageInfo);
		return request;
	}

	@Override
	public String updateUserRoles(int userId, int[] roleIds) {
		List<Integer> roleNeedToDel=new LinkedList<>(userMapper.findUserRoles(userId));
		List<Integer> roleNeedToAdd=new ArrayList<Integer>();
		//处理新增和删除
		for(int roleId:roleIds) {
			int point=roleNeedToDel.indexOf(roleId);
			if(point==-1) {
				roleNeedToAdd.add(roleId);
			}else {
				roleNeedToDel.remove(point);
			}
		}
		if(roleNeedToAdd.size()!=0) {
			Map<String, Object> params=new HashMap<String,Object>();
			params.put("list", roleNeedToAdd);
			params.put("uId", userId);
			userMapper.insertUserRoles(params);
		}
		if(roleNeedToDel.size()!=0) {
			Map<String, Object> params=new HashMap<String,Object>();
			params.put("list", roleNeedToDel);
			params.put("uId", userId);
			userMapper.deleteUserRoles(params);
		}
		return "ok";
	}
	
}
