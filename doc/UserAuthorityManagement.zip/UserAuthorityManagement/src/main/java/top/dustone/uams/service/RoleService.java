package top.dustone.uams.service;

import java.util.List;

import top.dustone.uams.pojo.Role;

public interface RoleService extends BaseService<Role>{
	public Integer[] findMenusByRoleId(int roleId);
	public String updateRoleMenus(int roleId,int[] menuIds);
	public List<Role> findSimpleRole();
}
