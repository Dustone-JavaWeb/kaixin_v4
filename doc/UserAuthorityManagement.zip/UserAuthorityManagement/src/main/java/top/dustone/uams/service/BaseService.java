package top.dustone.uams.service;

import java.util.List;

import top.dustone.uams.util.AjaxModel;

public interface BaseService<T>{
	public AjaxModel<T> listByExample(AjaxModel<T> request);
	public AjaxModel<T> findById(AjaxModel<T> request);
	public T update(T t);
	public T insert(T t);
	public T logicDelete(T t);
}
