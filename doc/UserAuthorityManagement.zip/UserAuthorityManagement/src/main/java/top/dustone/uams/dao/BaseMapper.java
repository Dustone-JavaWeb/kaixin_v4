package top.dustone.uams.dao;

import java.util.List;

import top.dustone.uams.pojo.User;
import top.dustone.uams.util.AjaxModel;

public interface BaseMapper <T>{
	public List<T> listByExample(T example);
	public List<T> listAll();
	public T findById(int id);
	public int insert(T entity);
	public int update(T entity);
	public int logicDelete(T entity);
}
