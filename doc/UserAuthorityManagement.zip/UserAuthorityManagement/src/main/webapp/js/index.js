var language, i18n;
var menuVue;
$(function() {
	Vue.use(VueI18n);
	i18n = new VueI18n({
		locale: 'zh', // 语言标识, 通过切换locale的值来实现语言切换,this.$i18n.locale 
		messages
	})
	var arr, reg = new RegExp("(^| )" + "language" + "=([^;]*)(;|$)"); //正则匹配
	if (arr = document.cookie.match(reg)) {
		language = (arr[2]);
	} else {
		language = 'zh';
	}
	i18n.locale = language;

	new Vue({
		el: '#leftDrawer',
		i18n,
		data: {
			menuItems: [],
			menuSelected: ''
		},
		mounted: function() {
			var self = this;
			menuVue = this;
			axios.get(SYSTEM_MENU).then(function(response) {
				self.menuItems = response.data;
			});
		},
		methods: {
			chooseMenu: function(url) {
				if (this.menuSelected != url) {
					$("#admin-page-container").load(url);
					this.menuSelected = url;
				}
			},
			selectedMenu: function(menuURL) {
				var self = this;
				if (menuURL == self.menuSelected) {
					return {
						'mdui-color-theme-accent': true
					}
				} else {
					return {
						'mdui-color-theme-accent': false
					}
				}
			}
		}
	})
	new Vue({
		el: '#toolbar',
		i18n,
		data: {
			sysUser: {}
		},
		mounted: function() {
			this.loadUserInfo();
		},
		methods: {
			loadUserInfo: function() {
				var self = this;
				axios.get(SYSTEM_USER_INFO).then(function(response) {
					if (response.data.code == "200") {
						self.sysUser = response.data.example;
					} else {

					}
				});
			},
			logOut: function() {
				axios.get(SYSTEM_USER_LOGOUT).then(function(response) {
					if (response.data.code == "200") {
						window.location.href = 'login.html';
					}
				});
			},
			switchLanguage: function(lang) {
				i18n.locale = lang;
				document.cookie = 'language=' + escape(lang);
				if (lang == 'en') {
					document.title = 'User Authority Management System';
				} else {
					document.title = '用户权限管理系统';
				}
			}
		}
	});
	menuVue.chooseMenu("childs/userManage.html");
	configAxiosInterceptors();
});
function configAxiosInterceptors(){
    axios.interceptors.response.use(function (response) {
    	var responseMsg=response.request.responseText;
        if(response.headers["content-length"]==258){
        	if(response.headers["content-type"]=="text/html;charset=utf-8") {
                mdui.snackbar({
                    message: "验证信息失效！ 三秒后返回登陆界面！",
                    timeout: 3000,
                    position: "right-bottom",
                });

                function skipToLogin() {
                    window.location.href = 'login.html';
                }

                var t = window.setTimeout(skipToLogin, 3000);
            }
		}
		else if(-1!=responseMsg.indexOf('授权失败！')){
            mdui.snackbar({
                message:response.data,
                buttonText: '关闭',
                timeout: 5000,
                position: "right-bottom",
            });
		}
        return response;
    }, function (error) {
        // Do something with response error
        return Promise.reject(error)
    })
}
