const BASE_URL="";
const BASE_URL2="http://localhost:8081/uams";
const SYSTEM_MENU=BASE_URL+"../json/menu.json";
const SYSTEM_USER_LOGIN=BASE_URL2+"/login";
const SYSTEM_USER_INFO=BASE_URL2+"/sys_info";
const SYSTEM_USER_LOGOUT=BASE_URL2+"/sys_logout";
//const SYSTEM_HOME=BASE_URL+"index.html";

const QUERY_USER=BASE_URL2+"/user/list";
const QUERY_USER_ROLES=BASE_URL2+"/user/listWithRoles";
const FIND_USER=BASE_URL2+"/user/findById";
const INSERT_USER=BASE_URL2+"/user/insert";
const UPDATE_USER=BASE_URL2+"/user/update";
const DELETE_USER=BASE_URL2+"/user/delete";
const CHECK_USER=BASE_URL2+"/user/checkAccountUnique";
// const FIND_USER_ROLES=BASE_URL2+"/user/findRoles";
const UPDATE_USER_ROLES=BASE_URL2+"/user/updateRoles"

const QUERY_ROLE=BASE_URL2+"/role/list";
const FIND_ROLE=BASE_URL2+"/role/findById";
const FIND_SIMPLE_ROLE=BASE_URL2+"/role/findSimple"
const INSERT_ROLE=BASE_URL2+"/role/insert";
const UPDATE_ROLE=BASE_URL2+"/role/update";
const DELETE_ROLE=BASE_URL2+"/role/delete";
const FIND_ROLE_MENUS=BASE_URL2+"/role/findMenus";
const UPDATE_ROLE_MENUS=BASE_URL2+"/role/updateMenus";

const QUERY_MENU=BASE_URL2+"/menu/list";
const QUERY_SIMPLE_MENU=BASE_URL2+"/menu/menuInfo";
const QUERY_MENU_TREE=BASE_URL2+"/menu/menuTree";
const FIND_MENU=BASE_URL2+"/menu/findById";
const INSERT_MENU=BASE_URL2+"/menu/insert";
const UPDATE_MENU=BASE_URL2+"/menu/update";
const DELETE_MENU=BASE_URL2+"/menu/delete";
