function jump(page, vue) {
	if ('first'== page && !vue.pageInfo.isFirstPage)
		vue.list(1);

	else if ('pre' == page && vue.pageInfo.hasPreviousPage)
		vue.list(vue.pageInfo.pageNum - 1);

	else if ('next' == page && vue.pageInfo.hasNextPage)
		vue.list(vue.pageInfo.pageNum + 1);

	else if ('last' == page && !vue.pageInfo.isLastPage)
		vue.list(vue.pageInfo.lastPage);
}
//分页跳转函数，跳转到指定页
function jumpByNumber(start, vue) {
	if (start != vue.pageInfo.pageNum)
		vue.list(start);
}
function DEEP_COPY(obj) {
	var result = JSON.parse(JSON.stringify(obj));
	return result;
}