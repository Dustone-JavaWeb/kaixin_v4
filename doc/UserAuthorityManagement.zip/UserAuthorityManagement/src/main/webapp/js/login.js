const SYSTEM_HOME="index.html";
$(function() {
	Vue.use(VueI18n);
	const i18n = new VueI18n({
		locale: 'zh', 
		messages
	});
	
	var language, arr, reg = new RegExp("(^| )" + "language" + "=([^;]*)(;|$)"); //正则匹配
	if (arr = document.cookie.match(reg)) {
		language = (arr[2]);
	} else {
		language = 'zh';
	}
	i18n.locale=language;
	
	new Vue({
		el: '#loginPanel',
		i18n,
		data: {
			loginUser:{
				accountNumber:'',
				password:''
			}
		},
		methods: {
			login: function() {
				var self=this;
				axios.post(SYSTEM_USER_LOGIN,self.loginUser).then(function(response){
					if(response.data.code=="200"){
						window.location.href = SYSTEM_HOME;
					}
				});
			},
			switchLanguage: function(lang) {
				i18n.locale = lang;
				document.cookie ='language=' + escape(lang);
				if(lang=='en'){
					document.title='User Authority Management System';
				}else{
					document.title='用户权限管理系统';
				}
			}
		}
	})
})
